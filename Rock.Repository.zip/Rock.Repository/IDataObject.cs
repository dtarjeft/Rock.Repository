﻿namespace Rock.Repository
{
    public interface IDataObject
    {
    }
}