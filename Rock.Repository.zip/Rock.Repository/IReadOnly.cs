﻿namespace Rock.Repository
{
    public interface IReadOnly
    {
        bool ReadOnly { get; set; }
    }
}