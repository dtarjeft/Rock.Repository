﻿namespace Rock.Repository
{
    public interface IAmDeletable
    {
        bool IsDelete { get; set; }
    }
}