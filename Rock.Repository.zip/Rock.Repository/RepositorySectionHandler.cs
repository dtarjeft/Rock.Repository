using Rock.Configuration;
using Rock.Repository.Configuration;

namespace Rock.Repository
{
    public class RepositorySectionHandler : XmlSerializerSectionHandler<XmlSerializingRockRepositoryConfiguration>
    {
    }
}