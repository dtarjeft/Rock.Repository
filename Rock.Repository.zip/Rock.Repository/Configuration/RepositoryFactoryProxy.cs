using Rock.Serialization;

namespace Rock.Repository.Configuration
{
    public class RepositoryFactoryProxy : XmlDeserializationProxy<IRepositoryFactory>
    {
    }
}